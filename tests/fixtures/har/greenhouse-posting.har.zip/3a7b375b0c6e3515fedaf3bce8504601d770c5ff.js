import{t,v as d}from"./entry.client-CYCVgZkQ.js";import"./vendor-T2hK1jFo.js";export{t as ErrorBoundary,d as default};
//# sourceMappingURL=root-CJMIV731.js.map
